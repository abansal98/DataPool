

let loginModel = {
    shouldShow: ko.observable(false),
}

let processModel = {
    shouldShow: ko.observable(true),
}

let signupModel = {
    shouldShow: ko.observable(false),
}

let genValues = {
    selectedEnv: ko.observable('TEST'),
    envs: ko.observableArray([
        { env: 'TEST' }, { env: "TEST2" }, { env: "TEST3" }])
}

function loginPage() {
    loginModel.shouldShow = true;
    signupModel.shouldShow = false;
    processModel.shouldShow = false;
}

$(document).ready(function () {
    ko.applyBindings(genValues, document.getElementById('main'));
    ko.applyBindings(loginModel, document.getElementById('loginPage'));
    ko.applyBindings(processModel, document.getElementById('processTable'));
    ko.applyBindings(signupModel, document.getElementById('signupPage'));
})